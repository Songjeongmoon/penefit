package com.penefit.moons.domain;

import lombok.Data;

@Data
public class CityVO {
	private String city_code;
	private String city_name;

/*
서울 A
경기B
인천C
강원D
충남E
대전F
충북G
부산H
울산I
대구J
경북K
경남L
전남M
광주N
전북O
제주P
온라인Z
*/
}
