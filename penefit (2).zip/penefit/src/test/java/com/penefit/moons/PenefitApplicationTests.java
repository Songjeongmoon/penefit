package com.penefit.moons;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PenefitApplicationTests {

	@Test
	void contextLoads() {
	}

}
