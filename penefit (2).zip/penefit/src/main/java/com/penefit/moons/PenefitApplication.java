package com.penefit.moons;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PenefitApplication {

	public static void main(String[] args) {
		SpringApplication.run(PenefitApplication.class, args);
	}

}
