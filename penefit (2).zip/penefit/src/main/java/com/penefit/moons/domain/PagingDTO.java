package com.penefit.moons.domain;

import lombok.Data;

@Data
public class PagingDTO {
	
	
	

}
