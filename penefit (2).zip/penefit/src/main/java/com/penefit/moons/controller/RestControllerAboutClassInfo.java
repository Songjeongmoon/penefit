package com.penefit.moons.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class RestControllerAboutClassInfo {
	
	

}
