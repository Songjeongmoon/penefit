package com.penefit.moons.service;

import com.penefit.moons.domain.NoticeVO;

public interface ServiceAboutAdminI {
	
	//공지사항 등록
	public int noticeReg(NoticeVO nvo);
	
	
}
